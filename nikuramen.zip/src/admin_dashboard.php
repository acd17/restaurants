<?php 
echo "admin";