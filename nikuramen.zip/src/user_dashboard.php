<?php 
echo "user";