<?php 

$sname = "localhost";
$uname = "id21449660_nikuramenadmin";
$password = "niku@Ramen2023";

$db_name = "id21449660_nikuramen";

$conn = mysqli_connect($sname, $uname, $password, $db_name);

if (!$conn) {
    echo "Connection Failed";
}